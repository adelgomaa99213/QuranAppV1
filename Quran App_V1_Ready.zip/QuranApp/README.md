# القرآن الكريم — V1 (قراءة وتصفح، Offline بالكامل)
Kotlin · Jetpack Compose · MVVM · minSdk 21 / targetSdk 34 · بدون أذونات وبدون إنترنت.

## المزايا
فهرس السور + بحث · وضع ملء الشاشة (Immersive) · تمرير تلقائي بشريط سرعة ·
حجم الخط 5–50 وحدة + تكبير بالأصابع · معاني الكلمات بالنقر · ثيم ذهبي + ليلي/نهاري + خلفيات قراءة ·
متابعة القراءة من آخر موضع.

## الهيكلية
```
app/src/main/
├─ AndroidManifest.xml
├─ assets/  quran.json · meanings.json (اختياري) · fonts/uthmanic_hafs.ttf (اختياري)
└─ java/com/quranapp/
   ├─ MainActivity.kt
   ├─ data/  Models · QuranRepository (JsonReader) · SettingsRepository (DataStore)
   └─ ui/    QuranApp · index/SurahIndexScreen · reader/{ReaderViewModel, QuranReaderScreen, FontSizeDialog} · theme/Theme
tools/build_assets.py
```

## ملفات البيانات (assets)
```bash
# اختبار الواجهة فوراً ببيانات تجريبية (ليست نص القرآن):
python3 tools/build_assets.py demo app/src/main/assets

# البيانات الحقيقية من مصدر موثوق بصيغة  sura|aya|text :
python3 tools/build_assets.py quran quran-uthmani.txt app/src/main/assets/quran.json
python3 tools/build_assets.py words app/src/main/assets/quran.json words.csv        # املأ عمود meaning
python3 tools/build_assets.py meanings words.csv app/src/main/assets/meanings.json
python3 tools/build_assets.py validate app/src/main/assets/quran.json --meanings app/src/main/assets/meanings.json
```
- `quran.json`: `{"basmala":"...","surahs":[{"number":1,"name":"الفاتحة","ayahs":[{"n":1,"t":"..."}]}]}`
- `meanings.json`: `{"كلمة":"معناها"}`
- الخط: ضع `uthmanic_hafs.ttf` في `assets/fonts/` (وإلا يُستخدم خط النظام تلقائياً).

## مصدر النص
نص المصحف من مشروع Tanzil (النسخة العثمانية 1.1، ترخيص CC BY 3.0) — https://tanzil.net . فُصلت البسملة عن الآية الأولى في السور 2–114 (عدا التوبة) لتُعرض كترويسة، دون تغيير أي حرف. لا تعدّل النص وأبقِ ذكر المصدر.

## تفسير الكلمات والآيات
- `assets/tafsir.json` (التفسير الميسر، مجمع الملك فهد، عبر Tanzil): **ضغط مطوّل على أي كلمة** يفتح نافذة بتفسير الآية.
- `assets/meanings.json` (اختياري): معاني الكلمات المفردة. إن وُجد، تظهر الكلمة مسطّرة بالذهبي والنقر عليها يعرض معناها.
  لا يحتوي الإصدار الحالي هذا الملف؛ ضع ملفاً **مراجَعاً** من مصدر معتمد (صيغته `{"كلمة":"معناها"}`).
  أمر `glosses` في الأداة يستخرج مرادفات من الجلالين آلياً لكنه تجريبي وفيه أخطاء، فلا تعتمده دون مراجعة.
- شروط الاستخدام: راجع tanzil.net/trans (النص لا يُعدَّل، ويُذكر المصدر).

## البناء التلقائي على GitHub
ارفع **محتويات** المجلد `QuranApp` (بحيث يكون `settings.gradle.kts` في جذر المستودع) ثم افتح تبويب Actions ▸ Build APK ▸ Run workflow.
بعد النجاح حمّل `Quran-App-debug-apk` من قسم Artifacts (APK للتجربة موقّع بمفتاح التطوير).
