package com.quranapp.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Typeface as ComposeTypeface
import androidx.core.view.WindowCompat

val Gold = Color(0xFFD4AF37)
val GoldSoft = Color(0xFFC5A059)
val PaperCream = Color(0xFFFBF3DF)

/**
 * خط المصحف: ضع الملف في app/src/main/assets/fonts/uthmanic_hafs.ttf (خط حفص).
 * إن لم يوجد يعمل التطبيق بخط النظام العربي دون أي خطأ.
 */
val LocalQuranFont = staticCompositionLocalOf<FontFamily> { FontFamily.Serif }

private fun loadHafs(ctx: Context): FontFamily = try {
    FontFamily(ComposeTypeface(android.graphics.Typeface.createFromAsset(ctx.assets, "fonts/uthmanic_hafs.ttf")))
} catch (e: Exception) {
    FontFamily.Serif
}

/** خلفيات القراءة القابلة للتغيير (تظهر حسب الوضع نهاري/ليلي). */
enum class ReaderBackground(val label: String, val color: Color, val text: Color, val dark: Boolean) {
    CREAM("كريمي (ورق المصحف)", Color(0xFFFBF3DF), Color(0xFF2B2417), false),
    WHITE("أبيض", Color(0xFFFFFFFF), Color(0xFF1A1A1A), false),
    SAND("رملي", Color(0xFFF1E4C3), Color(0xFF2B2417), false),
    MINT("أخضر هادئ", Color(0xFFE6EFE0), Color(0xFF1F2A1C), false),
    CHARCOAL("رمادي داكن", Color(0xFF1C1C1E), Color(0xFFEDE3C8), true),
    BLACK("أسود", Color(0xFF000000), Color(0xFFE6DCC0), true),
    NIGHT_BLUE("أزرق ليلي", Color(0xFF0F1724), Color(0xFFE9E1CC), true);

    companion object { fun forMode(dark: Boolean) = values().filter { it.dark == dark } }
}

private val LightColors = lightColorScheme(
    primary = Gold, onPrimary = Color.Black, secondary = GoldSoft,
    background = PaperCream, surface = Color(0xFFFFFBF0), onSurface = Color(0xFF3A3220),
)
private val DarkColors = darkColorScheme(
    primary = Gold, onPrimary = Color.Black, secondary = GoldSoft,
    background = Color(0xFF121212), surface = Color(0xFF1E1E1E), onSurface = Color(0xFFEFE6CF),
)

@Suppress("DEPRECATION")
@Composable
fun QuranTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val font = remember { loadHafs(ctx) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            (view.context as? Activity)?.window?.let { w ->
                w.statusBarColor = android.graphics.Color.TRANSPARENT
                w.navigationBarColor = android.graphics.Color.TRANSPARENT
                WindowCompat.getInsetsController(w, view).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }
        }
    }
    CompositionLocalProvider(LocalQuranFont provides font) {
        MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
    }
}
