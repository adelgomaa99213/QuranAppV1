package com.quranapp.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")

data class Settings(
    val fontSize: Int = 28,          // وحدات الخط (5..50)
    val dark: Boolean? = null,       // null = حسب النظام
    val bgIndex: Int = 0,
    val speed: Float = 0.3f,         // سرعة التمرير التلقائي 0..1
    val lastSurah: Int = 0,          // 0 = لا يوجد موضع محفوظ
    val lastAyah: Int = 1,
)

class SettingsRepository(private val ctx: Context) {
    private val FONT = intPreferencesKey("font")
    private val DARK = booleanPreferencesKey("dark")
    private val BG = intPreferencesKey("bg")
    private val SPEED = floatPreferencesKey("speed")
    private val LAST_SURAH = intPreferencesKey("last_surah")
    private val LAST_AYAH = intPreferencesKey("last_ayah")

    val flow = ctx.store.data.map { p ->
        Settings(
            fontSize = p[FONT] ?: 28,
            dark = p[DARK],
            bgIndex = p[BG] ?: 0,
            speed = p[SPEED] ?: 0.3f,
            lastSurah = p[LAST_SURAH] ?: 0,
            lastAyah = p[LAST_AYAH] ?: 1,
        )
    }

    suspend fun setFont(v: Int) = ctx.store.edit { it[FONT] = v }
    suspend fun setDark(v: Boolean) = ctx.store.edit { it[DARK] = v }
    suspend fun setBg(v: Int) = ctx.store.edit { it[BG] = v }
    suspend fun setSpeed(v: Float) = ctx.store.edit { it[SPEED] = v }
    suspend fun setLastRead(surah: Int, ayah: Int) = ctx.store.edit {
        it[LAST_SURAH] = surah; it[LAST_AYAH] = ayah
    }
}
