package com.quranapp.ui.reader

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quranapp.data.Ayah
import com.quranapp.ui.theme.*
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun QuranReaderScreen(vm: ReaderViewModel, onOpenIndex: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val opened by vm.opened.collectAsStateWithLifecycle()
    val surah = opened?.surah
    val startAyah = opened?.startAyah

    val dark = s.dark ?: isSystemInDarkTheme()
    val bgOptions = ReaderBackground.forMode(dark)
    val bg = bgOptions[s.bgIndex.coerceIn(0, bgOptions.lastIndex)]
    val minF = MIN_FONT_UNIT.toFloat()
    val maxF = MAX_FONT_UNIT.toFloat()

    var barsVisible by rememberSaveable { mutableStateOf(true) }
    var autoScroll by rememberSaveable { mutableStateOf(false) }
    var showFont by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<WordSheet?>(null) }

    // قيم حيّة أثناء الـ Pinch والسحب (تُحفظ عند الانتهاء فقط)
    var liveSize by remember { mutableFloatStateOf(s.fontSize.toFloat().coerceIn(minF, maxF)) }
    LaunchedEffect(s.fontSize) { liveSize = s.fontSize.toFloat().coerceIn(minF, maxF) }
    var liveSpeed by remember { mutableFloatStateOf(s.speed) }
    LaunchedEffect(s.speed) { liveSpeed = s.speed }

    val listState = rememberLazyListState()
    val density = LocalDensity.current.density
    val pxPerSec by rememberUpdatedState((15f + liveSpeed * 250f) * density)

    ImmersiveEffect(immersive = !barsVisible)

    // الانتقال إلى آية البداية (متابعة القراءة) أو إلى أول السورة
    LaunchedEffect(surah?.number, startAyah) {
        val sr = surah ?: return@LaunchedEffect
        val idx = sr.ayahs.indexOfFirst { it.number == startAyah }
        listState.scrollToItem(if (startAyah == null || idx < 0) 0 else idx + 1)
    }

    // حفظ موضع القراءة تلقائياً (بعد توقف التمرير)
    LaunchedEffect(surah?.number) {
        val sr = surah ?: return@LaunchedEffect
        snapshotFlow { listState.firstVisibleItemIndex }
            .debounce(800)
            .collect { i ->
                sr.ayahs.getOrNull((i - 1).coerceAtLeast(0))?.let { vm.saveProgress(sr.number, it.number) }
            }
    }

    // لمس القائمة بإصبع يوقف التمرير التلقائي
    LaunchedEffect(Unit) {
        listState.interactionSource.interactions.collect { if (it is DragInteraction.Start) autoScroll = false }
    }

    // تمرير تلقائي سلس (حسب الإطارات)
    LaunchedEffect(autoScroll) {
        if (!autoScroll) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            listState.scrollBy(pxPerSec * dt)
            if (!listState.canScrollForward) { autoScroll = false; break }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            Modifier.fillMaxSize().background(bg.color)
                .pinchToZoom(
                    onZoom = { liveSize = (liveSize * it).coerceIn(minF, maxF) },
                    onEnd = { vm.setFont(liveSize.roundToInt().coerceIn(MIN_FONT_UNIT, MAX_FONT_UNIT)) }
                )
        ) {
            if (surah != null) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                        detectTapGestures(onTap = { barsVisible = !barsVisible })
                    },
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 96.dp)
                ) {
                    item(key = "header") {
                        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            Text(
                                "سورة ${surah.name}", color = Gold, fontFamily = LocalQuranFont.current,
                                fontSize = 30.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                                    .border(1.dp, Gold, RoundedCornerShape(12.dp)).padding(12.dp)
                            )
                            surah.basmala?.let { b ->
                                Text(
                                    b, color = bg.text, fontFamily = LocalQuranFont.current,
                                    fontSize = (liveSize * 0.9f).sp, textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                                )
                            }
                        }
                    }
                    items(surah.ayahs, key = { it.number }) { ayah ->
                        AyahItem(
                            ayah = ayah, fontSize = liveSize, color = bg.text,
                            meaningOf = vm::meaningOf,
                            onWordTap = { w ->
                                val m = vm.meaningOf(w)
                                if (m != null) sheet = WordSheet(w, m, surah.number, ayah.number)
                                else barsVisible = !barsVisible
                            },
                            // ضغط مطوّل على أي كلمة: تفسير الآية (الميسر) + معنى الكلمة إن وُجد
                            onWordLong = { w -> sheet = WordSheet(w, vm.meaningOf(w), surah.number, ayah.number) },
                        )
                    }
                }
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
            }

            AnimatedVisibility(
                visible = barsVisible, modifier = Modifier.align(Alignment.TopCenter),
                enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }
            ) {
                TopBar(
                    title = surah?.name ?: "",
                    dark = dark, bgOptions = bgOptions, bgIndex = s.bgIndex,
                    onIndex = onOpenIndex, onFont = { showFont = true },
                    onBg = vm::setBg, onToggleDark = { vm.setDark(!dark) }
                )
            }

            AnimatedVisibility(
                visible = barsVisible, modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }
            ) {
                BottomBar(
                    autoScroll = autoScroll, onToggle = { autoScroll = !autoScroll },
                    speed = liveSpeed, onSpeed = { liveSpeed = it }, onSpeedDone = { vm.setSpeed(liveSpeed) }
                )
            }
        }

        if (showFont) FontSizeDialog(
            current = liveSize.roundToInt().coerceIn(MIN_FONT_UNIT, MAX_FONT_UNIT),
            onSelect = { vm.setFont(it); liveSize = it.toFloat(); showFont = false },
            onDismiss = { showFont = false }
        )

        sheet?.let { sh ->
            val tafsir by produceState("جارٍ التحميل…", sh.surah, sh.ayah) {
                value = vm.tafsirOf(sh.surah, sh.ayah) ?: "لا يتوفر تفسير لهذه الآية (تأكد من وجود tafsir.json في assets)"
            }
            ModalBottomSheet(onDismissRequest = { sheet = null }) {
                Column(
                    Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        .padding(24.dp).navigationBarsPadding(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(sh.word, fontFamily = LocalQuranFont.current, fontSize = 36.sp, color = Gold)
                    sh.meaning?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, fontSize = 18.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                    }
                    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Gold)
                    Text("تفسير الآية — التفسير الميسر", fontSize = 13.sp, color = GoldSoft)
                    Spacer(Modifier.height(8.dp))
                    Text(tafsir, fontSize = 17.sp, lineHeight = 28.sp, textAlign = TextAlign.Justify,
                        color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

/* ---------------------------- الآية ---------------------------- */

@Composable
private fun AyahItem(
    ayah: Ayah, fontSize: Float, color: Color,
    meaningOf: (String) -> String?,
    onWordTap: (String) -> Unit, onWordLong: (String) -> Unit,
) {
    // الكلمات الغريبة تظهر بلون ذهبي ومسطّرة
    val text = remember(ayah) {
        buildAnnotatedString {
            ayah.text.split(' ').forEachIndexed { i, w ->
                if (i > 0) append(' ')
                if (meaningOf(w) != null)
                    withStyle(SpanStyle(color = GoldSoft, textDecoration = TextDecoration.Underline)) { append(w) }
                else append(w)
            }
            append(' ')
            withStyle(SpanStyle(color = Gold)) { append("﴿${arabicDigits(ayah.number)}﴾") }
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    fun wordAt(pos: Offset): String? {
        val l = layout ?: return null
        val t = text.text
        val o = l.getOffsetForPosition(pos).coerceIn(0, t.lastIndex)
        var st = o; while (st > 0 && t[st - 1] != ' ') st--
        var en = o; while (en < t.length && t[en] != ' ') en++
        return t.substring(st, en).takeIf { it.isNotBlank() }
    }

    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
        Text(
            text = text, color = color, fontFamily = LocalQuranFont.current,
            fontSize = fontSize.sp, lineHeight = (fontSize * 1.9f).sp,
            textAlign = TextAlign.Justify,
            onTextLayout = { layout = it },
            modifier = Modifier.fillMaxWidth().pointerInput(ayah) {
                detectTapGestures(
                    onTap = { p -> wordAt(p)?.let(onWordTap) },
                    onLongPress = { p -> wordAt(p)?.let(onWordLong) }
                )
            }
        )
        HorizontalDivider(Modifier.padding(top = 6.dp), color = Gold.copy(alpha = 0.35f))
    }
}

private data class WordSheet(val word: String, val meaning: String?, val surah: Int, val ayah: Int)

private fun arabicDigits(n: Int) = n.toString().map { '٠' + (it - '0') }.joinToString("")

/* ---------------------------- الأشرطة ---------------------------- */

@Composable
private fun TopBar(
    title: String, dark: Boolean, bgOptions: List<ReaderBackground>, bgIndex: Int,
    onIndex: () -> Unit, onFont: () -> Unit, onBg: (Int) -> Unit, onToggleDark: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f), shadowElevation = 4.dp) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onIndex) { Icon(Icons.Default.Menu, "الفهرس", tint = Gold) }
            Text(title, Modifier.weight(1f), color = Gold, fontFamily = LocalQuranFont.current, fontSize = 22.sp)
            IconButton(onFont) { Icon(Icons.Default.FormatSize, "حجم الخط", tint = Gold) }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.Palette, "الخلفية", tint = Gold) }
                DropdownMenu(menu, { menu = false }) {
                    bgOptions.forEachIndexed { i, o ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(22.dp).clip(CircleShape).background(o.color)
                                            .border(
                                                if (i == bgIndex.coerceIn(0, bgOptions.lastIndex)) 2.dp else 1.dp,
                                                Gold, CircleShape
                                            )
                                    )
                                    Spacer(Modifier.width(10.dp)); Text(o.label)
                                }
                            },
                            onClick = { onBg(i); menu = false }
                        )
                    }
                }
            }
            IconButton(onToggleDark) {
                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "الوضع", tint = Gold)
            }
        }
    }
}

@Composable
private fun BottomBar(
    autoScroll: Boolean, onToggle: () -> Unit,
    speed: Float, onSpeed: (Float) -> Unit, onSpeedDone: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f), shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onToggle, Modifier.size(52.dp)) {
                Icon(
                    if (autoScroll) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "تمرير تلقائي", tint = Gold, modifier = Modifier.size(36.dp)
                )
            }
            Text("بطيء", fontSize = 12.sp, color = GoldSoft)
            Slider(
                value = speed, onValueChange = onSpeed, onValueChangeFinished = onSpeedDone,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Gold.copy(alpha = 0.3f)
                )
            )
            Text("سريع", fontSize = 12.sp, color = GoldSoft)
        }
    }
}

/* ---------------------------- أدوات مساعدة ---------------------------- */

/** إخفاء/إظهار شريطي الحالة والتنقل (Immersive). */
@Composable
private fun ImmersiveEffect(immersive: Boolean) {
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (immersive) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }
    // عند مغادرة القارئ (الرجوع للفهرس) نُعيد إظهار أشرطة النظام
    DisposableEffect(Unit) {
        onDispose {
            (view.context as? Activity)?.window?.let {
                WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
}

/** تكبير/تصغير بإصبعين دون تعطيل التمرير بإصبع واحد. */
private fun Modifier.pinchToZoom(onZoom: (Float) -> Unit, onEnd: () -> Unit) =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var zoomed = false
            do {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                if (ev.changes.size >= 2) {
                    val z = ev.calculateZoom()
                    if (z != 1f) { onZoom(z); zoomed = true }
                    ev.changes.forEach { it.consume() }
                }
            } while (ev.changes.any { it.pressed })
            if (zoomed) onEnd()
        }
    }
