package com.quranapp.data

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.InputStreamReader

/**
 * مصدر البيانات الوحيد (Offline): assets/quran.json و assets/meanings.json
 *
 * quran.json    : {"basmala":"...","surahs":[{"number":1,"name":"الفاتحة","ayahs":[{"n":1,"t":"..."}]}]}
 *                 (يُقبل أيضاً مصفوفة السور مباشرة)
 * meanings.json : {"كلمة":"معناها", ...}   (اختياري؛ غيابه لا يوقف التطبيق)
 *
 * القراءة بـ JsonReader (Streaming) دون بناء شجرة JSON كاملة لتوفير الذاكرة والوقت.
 */
class QuranRepository(private val ctx: Context) {
    private val mutex = Mutex()
    @Volatile private var data: QuranData? = null
    @Volatile private var meanings: Map<String, String> = emptyMap()
    private val tafsirMutex = Mutex()
    @Volatile private var tafsirMap: Map<String, String>? = null

    /** تحميل مرة واحدة ثم من الذاكرة. يرمي استثناءً عند غياب/تلف quran.json. */
    suspend fun load(): QuranData {
        data?.let { return it }
        return mutex.withLock {
            data ?: withContext(Dispatchers.IO) {
                val d = parseQuran()
                meanings = runCatching { parseMeanings() }.getOrDefault(emptyMap())
                d
            }.also { data = it }
        }
    }

    /** بعد نجاح load() تُرجع السورة فوراً دون تعليق. */
    fun surahOrNull(number: Int): Surah? = data?.surahs?.firstOrNull { it.number == number }

    /** معنى الكلمة (يتجاهل التشكيل ويجرّب إزالة السوابق: و ف ب ل ك + ال). */
    fun meaning(word: String): String? {
        val m = meanings
        if (m.isEmpty()) return null
        val n = normalize(word)
        if (n.length < 2) return null
        m[n]?.let { return it }
        val bases = if (n.first() in "وفبلك") listOf(n, n.substring(1)) else listOf(n)
        for (b in bases) {
            if (b != n && b.length >= 2) m[b]?.let { return it }
            if (b.startsWith("ال") && b.length > 3) m[b.substring(2)]?.let { return it }
        }
        return null
    }

    /** تفسير الآية (الميسر) من assets/tafsir.json، يُحمَّل عند أول طلب فقط. */
    suspend fun tafsir(surah: Int, ayah: Int): String? {
        val m = tafsirMap ?: tafsirMutex.withLock {
            tafsirMap ?: withContext(Dispatchers.IO) {
                runCatching { parseTafsir() }.getOrDefault(emptyMap())
            }.also { tafsirMap = it }
        }
        return m["$surah:$ayah"]
    }

    private fun parseTafsir(): Map<String, String> {
        val out = HashMap<String, String>(7000)
        open("tafsir.json").use { r ->
            r.beginObject()
            while (r.hasNext()) {
                val k = r.nextName()
                if (!k.startsWith("_") && r.peek() == JsonToken.STRING) out[k] = r.nextString() else r.skipValue()
            }
            r.endObject()
        }
        return out
    }

    /* ----------------------------- التحليل ----------------------------- */

    private fun open(name: String) =
        JsonReader(InputStreamReader(ctx.assets.open(name), Charsets.UTF_8).buffered())

    private fun parseQuran(): QuranData {
        var basmala: String? = null
        var surahs: List<Surah> = emptyList()
        open("quran.json").use { r ->
            if (r.peek() == JsonToken.BEGIN_ARRAY) {
                surahs = r.readSurahs()
            } else {
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "basmala" -> basmala = r.nextString()
                        "surahs" -> surahs = r.readSurahs()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
            }
        }
        check(surahs.isNotEmpty()) { "quran.json لا يحتوي سوراً" }
        val b = basmala?.takeIf { it.isNotBlank() }
        val full = surahs.sortedBy { it.number }.map {
            if (b != null && it.number != 1 && it.number != 9) it.copy(basmala = b) else it
        }
        return QuranData(full, full.map { SurahInfo(it.number, it.name, it.ayahs.size) })
    }

    private fun parseMeanings(): Map<String, String> {
        val out = HashMap<String, String>()
        open("meanings.json").use { r ->
            r.beginObject()
            while (r.hasNext()) {
                val rawKey = r.nextName()
                val key = normalize(rawKey)
                if (!rawKey.startsWith("_") && r.peek() == JsonToken.STRING) {
                    val v = r.nextString()
                    if (key.isNotEmpty() && key !in out) out[key] = v
                } else r.skipValue()
            }
            r.endObject()
        }
        return out
    }

    companion object {
        private val noise =
            Regex("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640\\u08D3-\\u08FF﴾﴿۝،.]")
        private val alef = Regex("[أإآٱ]")

        /** يجب أن يطابق normalize في tools/build_assets.py */
        fun normalize(w: String) = alef.replace(noise.replace(w, ""), "ا").trim()

        /** بحث الفهرس: برقم السورة أو باسمها (بدون تشكيل). */
        fun filter(list: List<SurahInfo>, raw: String): List<SurahInfo> {
            val q = latinDigits(raw.trim())
            if (q.isEmpty()) return list
            if (q.all { it.isDigit() }) return list.filter { it.number.toString().startsWith(q) }
            val nq = normalize(q)
            return list.filter { normalize(it.name).contains(nq) }
        }

        private fun latinDigits(s: String) =
            s.map { if (it in '٠'..'٩') '0' + (it - '٠') else it }.joinToString("")
    }
}

private fun JsonReader.readSurahs(): List<Surah> {
    val out = ArrayList<Surah>(114)
    beginArray()
    while (hasNext()) out += readSurah()
    endArray()
    return out
}

private fun JsonReader.readSurah(): Surah {
    var number = 0
    var name = ""
    var ayahs: List<Ayah> = emptyList()
    beginObject()
    while (hasNext()) {
        when (nextName()) {
            "number" -> number = nextInt()
            "name" -> name = nextString()
            "ayahs" -> ayahs = readAyahs()
            else -> skipValue()
        }
    }
    endObject()
    return Surah(number, name, ayahs)
}

private fun JsonReader.readAyahs(): List<Ayah> {
    val out = ArrayList<Ayah>()
    beginArray()
    while (hasNext()) {
        var n = 0
        var t = ""
        beginObject()
        while (hasNext()) {
            when (nextName()) {
                "n" -> n = nextInt()
                "t" -> t = nextString()
                else -> skipValue()
            }
        }
        endObject()
        out += Ayah(n, t)
    }
    endArray()
    return out
}
