package com.quranapp.ui.index

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quranapp.data.LastRead
import com.quranapp.data.LoadState
import com.quranapp.data.SurahInfo
import com.quranapp.ui.reader.ReaderViewModel
import com.quranapp.ui.theme.Gold
import com.quranapp.ui.theme.GoldSoft
import com.quranapp.ui.theme.LocalQuranFont

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahIndexScreen(vm: ReaderViewModel, onOpen: (surah: Int, ayah: Int?) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val load by vm.loadState.collectAsStateWithLifecycle()
    val list by vm.filteredIndex.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val last by vm.lastRead.collectAsStateWithLifecycle()
    val dark = s.dark ?: isSystemInDarkTheme()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("القرآن الكريم", color = Gold, fontFamily = LocalQuranFont.current, fontSize = 26.sp) },
                    actions = {
                        IconButton({ vm.setDark(!dark) }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "الوضع", tint = Gold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (val st = load) {
                    LoadState.Loading ->
                        CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)

                    is LoadState.Error ->
                        Column(
                            Modifier.align(Alignment.Center).padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(st.message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = vm::reload,
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = androidx.compose.ui.graphics.Color.Black)
                            ) { Text("إعادة المحاولة") }
                        }

                    LoadState.Ready -> IndexList(list, query, vm::setQuery, last, onOpen)
                }
            }
        }
    }
}

@Composable
private fun IndexList(
    list: List<SurahInfo>, query: String, onQuery: (String) -> Unit,
    last: LastRead?, onOpen: (Int, Int?) -> Unit,
) {
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item {
            OutlinedTextField(
                value = query, onValueChange = onQuery, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                placeholder = { Text("ابحث باسم السورة أو رقمها") },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton({ onQuery("") }) { Icon(Icons.Default.Close, "مسح", tint = Gold) }
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold, unfocusedBorderColor = GoldSoft.copy(alpha = 0.5f), cursorColor = Gold
                )
            )
        }
        if (last != null && query.isBlank()) {
            item { ResumeCard(last) { onOpen(last.surahNumber, last.ayah) } }
        }
        items(list, key = { it.number }) { info -> SurahRow(info) { onOpen(info.number, null) } }
        item {
            // اشتراط ترخيص Tanzil: ذكر المصدر مع رابط الموقع
            Text(
                "نص المصحف والتفسير الميسر (مجمع الملك فهد): مشروع تنزيل Tanzil — tanzil.net",
                Modifier.fillMaxWidth().padding(vertical = 24.dp),
                textAlign = TextAlign.Center, fontSize = 12.sp, color = GoldSoft
            )
        }
        if (list.isEmpty()) {
            item {
                Text(
                    "لا توجد نتائج", Modifier.fillMaxWidth().padding(32.dp),
                    textAlign = TextAlign.Center, color = GoldSoft
                )
            }
        }
    }
}

@Composable
private fun ResumeCard(last: LastRead, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.12f)),
        border = BorderStroke(1.dp, Gold)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, null, tint = Gold)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("متابعة القراءة", color = Gold, fontWeight = FontWeight.Bold)
                Text(
                    "سورة ${last.surahName} — الآية ${arabicDigits(last.ayah)}",
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun SurahRow(info: SurahInfo, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).border(1.5.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
                Text(arabicDigits(info.number), color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(info.name, fontFamily = LocalQuranFont.current, fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurface)
                Text("${arabicDigits(info.ayahCount)} آية", fontSize = 13.sp, color = GoldSoft)
            }
        }
        HorizontalDivider(color = Gold.copy(alpha = 0.2f))
    }
}

private fun arabicDigits(n: Int) = n.toString().map { '٠' + (it - '0') }.joinToString("")
