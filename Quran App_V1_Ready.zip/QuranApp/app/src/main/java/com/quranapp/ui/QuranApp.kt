package com.quranapp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.quranapp.ui.index.SurahIndexScreen
import com.quranapp.ui.reader.QuranReaderScreen
import com.quranapp.ui.reader.ReaderViewModel
import com.quranapp.ui.theme.QuranTheme

/** تنقّل بسيط: الفهرس ⇄ القارئ مع زر الرجوع. ViewModel واحد مشترك. */
@Composable
fun QuranApp(vm: ReaderViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val opened by vm.opened.collectAsStateWithLifecycle()
    val dark = s.dark ?: isSystemInDarkTheme()

    var inReader by rememberSaveable { mutableStateOf(false) }
    val showReader = inReader && opened != null   // يحمي من استعادة الحالة بعد قتل العملية

    BackHandler(enabled = showReader) { inReader = false }

    QuranTheme(dark = dark) {
        Crossfade(targetState = showReader, label = "screen") { reader ->
            if (reader) {
                QuranReaderScreen(vm, onOpenIndex = { inReader = false })
            } else {
                SurahIndexScreen(vm) { surah, ayah ->
                    vm.openSurah(surah, ayah)
                    inReader = true
                }
            }
        }
    }
}
